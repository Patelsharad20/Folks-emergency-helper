package com.example.remoteprinting;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class Hospitals extends AppCompatActivity {



//    private static final String TAG = "DocFragment";
//    private ArrayList<String> mNames = new ArrayList<>();
//    private ArrayList<String> mImageUrls = new ArrayList<>();
//    private ArrayList<String> mMail = new ArrayList<>();
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_hospitals);
//
//        initImageBitmaps();
//    }
//
//
//
//
//
//    private void initImageBitmaps(){
//
//        mImageUrls.add("https://www.bing.com/images/search?q=Apollo+Hospital+Logo&FORM=IRTRRL");
//        mNames.add("Apollo Hospital");
//        mMail.add("xyzemail@gmail.com");
//
//        mImageUrls.add("https://www.devasyahospital.com/wp-content/uploads/2018/12/logo.png");
//        mNames.add("Devasya kidney Hospitals");
//
//        mImageUrls.add("https://www.joonsquare.com/usermanage/image/business/sterling-hospital-rajkot-5773/sterling-hospital-rajkot-logo.jpg");
//        mNames.add("Sterling Hospital");
//
//        mImageUrls.add("https://bingo.icbse.com/business.jpg?action=logo&id=v30p5p");
//        mNames.add("Civil Hospital");
//
//        mImageUrls.add("https://www.joonsquare.com/usermanage/image/business/rajasthan-hospital-ahmedabad-5434/rajasthan-hospital-ahmedabad-logo.png");
//        mNames.add("Rajasthan Hospital");
//
//        mImageUrls.add("https://ehealth.eletsonline.com/wp-content/uploads/2016/05/Shalby-Hospitals-Ahmedabad-logo.jpg");
//        mNames.add("Shalby Hospital");
//
//        initRecyclerView();
//    }
//
//    private void initRecyclerView(){
//
//        Log.d(TAG, "initRecyclerView: init recyclerview.");
//
//
//
//
//        RecyclerView recyclerView = findViewById(R.id.recycler_view);
//
//        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mNames , mImageUrls,mMail);
//        recyclerView.setAdapter(adapter);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//
//
//    }


}