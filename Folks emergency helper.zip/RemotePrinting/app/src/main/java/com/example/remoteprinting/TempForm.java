package com.example.remoteprinting;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import com.hbb20.CountryCodePicker;

public class TempForm extends AppCompatActivity {

//    EditText userName, userAddress, userPhone;
//    CountryCodePicker ccp;
//    Button regButton;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_form);

//        setupUIViews();


//        getSupportActionBar().setTitle("Form");
//        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);
//
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);




//        final EditText e1 = (EditText) findViewById(R.id.e1);
//        final EditText e2 = (EditText) findViewById(R.id.e2);
//        final RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
//        Button button = (Button) findViewById(R.id.button);
//        regButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(Intent.ACTION_SEND);
//                i.setType("message/plain");
//                i.putExtra(Intent.EXTRA_EMAIL, new String[]{"parthspatel2000@gmail.com"});
//                i.putExtra(Intent.EXTRA_SUBJECT, "User Form");
//                i.putExtra(Intent.EXTRA_TEXT, "Name:" + userName.getText() + "\n Phone:" +ccp.getSelectedCountryCodeWithPlus()+ userPhone.getText() + "\n Address:" + userAddress.getText());
//
//                try {
//                    startActivity(Intent.createChooser(i, "Please select Email"));
//                } catch (android.content.ActivityNotFoundException ex) {
//                    Toast.makeText(TempForm.this, "there are no email client", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//    }
//
//
//    private void setupUIViews() {
//        userName = findViewById(R.id.fUserName);
//        userAddress = findViewById(R.id.fAddress);
//        regButton = findViewById(R.id.fRegister);
//        userPhone = findViewById(R.id.fPhone);
//        ccp = findViewById(R.id.fccp);
//
    }

}
