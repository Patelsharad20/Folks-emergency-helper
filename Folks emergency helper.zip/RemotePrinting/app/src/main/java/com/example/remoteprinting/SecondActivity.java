package com.example.remoteprinting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    static final float END_SCALE= 0.7f;

    private FirebaseAuth firebaseAuth;
    ImageView menuIcon,plus;
    LinearLayout contentView;

    TextInputLayout Name, Password;

    TextInputLayout profileName,profileEmail,profilePhone;

    RecyclerView featuredRecycler;
//    RecyclerView.Adapter adapter;
    RecyclerView mostViewedRecycler;

//    private GradientDrawable gradient1,gradient2,gradient3,gradient4;

    DrawerLayout drawerLayout;
    NavigationView navigationView;

//    SearchView sView;
//    ListView listView;
//
//    ArrayList<String> list;
//    ArrayAdapter<String> adapter;


    private static final String TAG = "DocFragment";
    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();
    private ArrayList<String> mMail = new ArrayList<>();
    private ArrayList<String> mPhone = new ArrayList<>();
    private ArrayList<String> mAddress = new ArrayList<>();

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

//        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        firebaseAuth = FirebaseAuth.getInstance();

//        logout = (Button)findViewById(R.id.btnLogout);

//        logout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//              Logout();
//            }
//        });


//        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
//        bottomNav.setOnNavigationItemSelectedListener(navListener);
//
//        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();

//        featuredRecycler = findViewById(R.id.featured_recycler);
//        mostViewedRecycler = findViewById(R.id.featured_mv);
        menuIcon = findViewById(R.id.menu_icon);

        plus = findViewById(R.id.pls);

        contentView = findViewById(R.id.content);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        profileName = findViewById(R.id.pidName);
        profileEmail = findViewById(R.id.pidEmail);
        profilePhone = findViewById(R.id.pidPhone);

        Name = findViewById(R.id.etName);
        Password = findViewById(R.id.etPassword);

//        sView = findViewById(R.id.searchView);
//        listView = findViewById(R.id.myList);

//        list = new ArrayList<String>();
//
////        list.add("Apollo Hospital");
//
//
//
//        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,mNames);
//
//        listView.setAdapter(adapter);
//
//
//        sView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                return false;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//
//                adapter.getFilter().filter(newText);
//                return false;
//            }
//        });




        navigationDrawer();

//        featuredRecycler();
//        mostViewedRecycler();

        initImageBitmaps();


        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SecondActivity.this,DashBoard.class));
            }
        });




    }







//    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
//            new BottomNavigationView.OnNavigationItemSelectedListener() {
//                @Override
//                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                    Fragment selectedFragment = null;
//
//                    switch (item.getItemId()){
//                        case R.id.home:
//                            selectedFragment = new HomeFragment();
//                            break;
//                        case R.id.doctors:
//                            selectedFragment = new DoctorsFragment();
//                            break;
//                        case R.id.pf:
//                            selectedFragment = new ProfileFragment();
//                            break;
//                    }
//
//                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
//
//                    return true;
//                }
//            };





    //Navigation Drawer function
    private void navigationDrawer() {
        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_home);


        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerVisible(GravityCompat.START)){
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                else drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        animateNavigationDrawer();
    }




    private void animateNavigationDrawer() {

        drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                contentView.setScaleX(offsetScale);
                contentView.setScaleY(offsetScale);

                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = contentView.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                contentView.setTranslationX(xTranslation);
            }
        });

    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerVisible(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else
            super.onBackPressed();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        switch (menuItem.getItemId()){
            case R.id.nav_home:
                break;
            case R.id.LogoutMenu:
                Logout();
                break;
            case R.id.nav_profile:{
                startActivity(new Intent(SecondActivity.this,ProfileActivity.class));
                break;
            }
            case R.id.nav_all_categories: {
                startActivity(new Intent(SecondActivity.this,FeedBack.class));
                break;
            }

            case R.id.news:{
                startActivity(new Intent(SecondActivity.this,Main_News.class));
                break;
            }
//            case R.id.fForm:{
//                startActivity(new Intent(SecondActivity.this,TempForm.class));
//                break;
//            }

//            case R.id.fHospitals:{
//                startActivity(new Intent(SecondActivity.this,Hospitals.class));
//                break;
//            }

        }


        return true;
    }

//    private void mostViewedRecycler() {
//
//
//        mostViewedRecycler.setHasFixedSize(true);
//        mostViewedRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
//
//        ArrayList<MostViewedHelperClass> mostViewedLocations = new ArrayList<>();
//        mostViewedLocations.add(new MostViewedHelperClass(R.drawable.apollo,"Apollo Hospital","Pancholi House, Prabhat Chowk, 61, Ghatlodia, Chanakyapuri, Ahmedabad, Gujarat 380013."));
//        mostViewedLocations.add(new MostViewedHelperClass(R.drawable.clinic, "Dr. Krishnakant M.Patel","Ankur Rd, near Ankur Bus Stand, Vijaynagar, Naranpura, Ahmedabad, Gujarat 380013."));
//
//        adapter = new MostViewedAdpater(mostViewedLocations);
//        mostViewedRecycler.setAdapter(adapter);
//
//    }



    private void initImageBitmaps(){

        mImageUrls.add("https://i2.wp.com/hbgmedicalassistance.com/wp-content/uploads/2017/09/Apollo-Hospitals-Group-logo-HBG-Medical-Assistance.jpg?fit=819%2C460");
        mNames.add("Apollo Hospital");
        mMail.add("info@apolloahd.com");
        mPhone.add("079 6670 1800");
        mAddress.add("Pancholi House, Prabhat Chowk, 61, Ghatlodiya, Chanakyapuri, Ahmedabad, Gujarat 380061");

        mImageUrls.add("https://www.devasyahospital.com/wp-content/uploads/2018/12/logo.png");
        mNames.add("Devasya kidney Hospitals");
        mMail.add("marketing@devasyahospital.com");
        mPhone.add(" 090999 25275");
        mAddress.add("2nd Floor, Samarpan Complex S.P Ring Road, nr. Ambli-bopal Circle, Gujarat 380059");

        mImageUrls.add("https://www.joonsquare.com/usermanage/image/business/sterling-hospital-rajkot-5773/sterling-hospital-rajkot-logo.jpg");
        mNames.add("Sterling Hospital");
        mMail.add("info@sterlingcancer.in");
        mPhone.add("079-40011111");
        mAddress.add("Sterling Cancer Hospital Road, B/h, Sindhu Bhavan Marg,Off S G Highway, Bodakdev, Ahmedabad, Gujarat 380054");

        mImageUrls.add("https://bingo.icbse.com/business.jpg?action=logo&id=v30p5p");
        mNames.add("Civil Hospital");
        mMail.add("aha.health.ahmedabadsola@gmail.com");
        mPhone.add("079 2268 3721");
        mAddress.add("D Block Asarwa, Haripura, Office of the Medical Superintendent Civil Hospital Ahmedabad Gujarat 380016 IN, Asarwa, Ahmedabad, Gujarat 380016");

        mImageUrls.add("https://www.joonsquare.com/usermanage/image/business/rajasthan-hospital-ahmedabad-5434/rajasthan-hospital-ahmedabad-logo.png");
        mNames.add("Rajasthan Hospital");
        mMail.add("curewithcare@grmi.org.in");
        mPhone.add("+91 79 22866311-12-13");
        mAddress.add("The Gujarat Research & Medical Institute Camp Road, Shahibaug Ahmedabad – 380 004 India – Gujarat");

        mImageUrls.add("https://ehealth.eletsonline.com/wp-content/uploads/2016/05/Shalby-Hospitals-Ahmedabad-logo.jpg");
        mNames.add("Shalby Hospital");
        mMail.add(" info@shalby.org");
        mPhone.add("(079) 40203154");
        mAddress.add("Opp. Karnavati Club, S G Road,Ahmedabad - 380015, Gujarat, India");

        mImageUrls.add("https://cdn.credihealth.com/system/attachments/objects/62739/original/narayana.jpg?1542358607");
        mNames.add("Narayana Hospital");
        mMail.add("info.ahd@narayanahealth.org");
        mPhone.add("+91-787 810 0900");
        mAddress.add("Nr. Chakudiya Mahadev, Rakhial Cross Road , Opp. Rakhial Police Station, Rakhial , Ahmedabad, Gujarat - 380023");


        mImageUrls.add("https://pbs.twimg.com/profile_images/940525468733751296/crarJ1mx.jpg");
        mNames.add("Cims Hospital");
        mMail.add("info@cims.org");
        mPhone.add("098250 66664");
        mAddress.add("Science City Rd, Science City, Panchamrut Bunglows II, Sola, Ahmedabad, Gujarat 380060");

        mImageUrls.add("https://cdn3.vectorstock.com/i/1000x1000/79/32/hospital-icon-black-isolated-icon-with-medical-vector-29377932.jpg");
        mNames.add("Kaizen Hospital");
        mMail.add("info@cims.org");
        mPhone.add("079/27914444");
        mAddress.add("132ft. Ring Road, Helmet Circle Memnagar, Ahmedabad – 380052 Gujarat, India.");

        mImageUrls.add("https://pbs.twimg.com/profile_images/1076124270269513732/MEnauN4n_400x400.jpg");
        mNames.add("SVP Hospital");
        mMail.add("svpimsr@gmail.com");
        mPhone.add("1234567890");
        mAddress.add("Ellisbridge, Ahmedabad, Gujarat 380006");


        mImageUrls.add("https://www.iconsdb.com/icons/preview/royal-blue/clinic-xxl.png");
        mNames.add("Shubham Maternity & Sonography Clinic");
        mMail.add("");
        mPhone.add("079 2749 2017");
        mAddress.add("Ist Floor, Shubham Complex, Ghatlodiya, Ghatlodiya, Ahmedabad, Gujarat 380061");



        mImageUrls.add("https://i.pinimg.com/236x/e7/eb/a9/e7eba94efdffad59ef9658be6f83bf17--logo-google-hospitals.jpg");
        mNames.add("Women's Hospital");
        mMail.add("info@evawomenshospital.com");
        mPhone.add("+91- 22682217");
        mAddress.add("Neelkanth Park, 2, Ghoda Camp Rd, near BSNL Office, Shahibag, Ahmedabad, Gujarat 380004");


        mImageUrls.add("https://pbs.twimg.com/profile_images/1344967203267874816/V6kFX2gz_400x400.jpg");
        mNames.add("Zydus hospital family clinic");
        mMail.add("ahmird@zydushospitals.com");
        mPhone.add("+91 99090 21667");
        mAddress.add("Zydus Hospitals Road,Nr. Sola Bridge, S.G. Highway,Ahmedabad - 380054,Gujarat, India.");


        mImageUrls.add("https://lifecarehosp.com/wp-content/uploads/2020/10/letter-head-new-2-1.png");
        mNames.add("Life Care Multispeciality Hospital");
        mMail.add("info@lifecare.co.in");
        mPhone.add("079 - 4020 4020");
        mAddress.add("Sardar Patel Statue Corner,Stadium Road, Ahmedabad-380 014 Gujarat, India");



        mImageUrls.add("https://social.kdhospital.co.in/data/fb_images/KDHospitalOfficial/1220793328060777.jpg");
        mNames.add("KD Hospital");
        mMail.add("contact@kdhospital.co.in");
        mPhone.add("+91 79 6677 0001");
        mAddress.add("Vaishnodevi Circle, SG Road,Ahmedabad - 382421");

        mImageUrls.add("https://media-exp1.licdn.com/dms/image/C510BAQHvEf88IL0NOA/company-logo_200_200/0/1526716518272?e=2159024400&v=beta&t=Ubvu4Mos6nsebsT7H4UoJIoSjnr9sJZLP0_0GF87Nhg");
        mNames.add("Global Hospital");
        mMail.add("info@globalhospital.co.in");
        mPhone.add("079-29708041");
        mAddress.add("GLOBAL HOSPITAL Nr. Bodakdev Garden, Pakwan Cross Road,Off. S.G. Highway, Bodakdev,Ahmedabad – 380 054");






        initRecyclerView();
    }

    private void initRecyclerView(){

        Log.d(TAG, "initRecyclerView: init recyclerview.");




        RecyclerView recyclerView = findViewById(R.id.featured_recycler);

        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mNames , mImageUrls,mMail,mPhone,mAddress);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }




//    private void featuredRecycler(){
//
//        featuredRecycler.setHasFixedSize(true);
//        featuredRecycler.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
//
//        ArrayList<FeaturedHelperClass> featuredLocations = new ArrayList<>();
//
//
//        featuredLocations.add(new FeaturedHelperClass(R.drawable.apollo,"Apollo Hospital","Pancholi House, Prabhat Chowk, 61, Ghatlodia, Chanakyapuri, Ahmedabad, Gujarat 380013."));
//        featuredLocations.add(new FeaturedHelperClass(R.drawable.clinic,"Dr. Krishnakant M.Patel","Ankur Rd, near Ankur Bus Stand, Vijaynagar, Naranpura, Ahmedabad, Gujarat 380013"));
//        //featuredLocations.add(new FeaturedHelperClass(R.drawable.xerox_shop4,"Xerox Copy Center","Near Akhbar Nagar Circle,New Vadaj Road,New Vadaj."));
//
//        adapter = new FeaturedAdpater(featuredLocations);
//        featuredRecycler.setAdapter(adapter);
//    }



    private void Logout(){
        AlertDialog.Builder builder = new AlertDialog.Builder(SecondActivity.this);
        builder.setMessage("Are You Sure you want to exit? ")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        firebaseAuth.signOut();
                        finish();
                        startActivity(new Intent(SecondActivity.this,MainActivity.class));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        startActivity(new Intent(getApplicationContext(),SecondActivity.class));
                        finish();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();


//        firebaseAuth.signOut();
//        finish();
//        startActivity(new Intent(SecondActivity.this,MainActivity.class));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

//        switch(item.getItemId()){
//            case R.id.logoutMenu:{
//                Logout();
//                break;
//            }
//            case R.id.nav_profile:{
//                startActivity(new Intent(SecondActivity.this,ProfileActivity.class));
//                break;
//            }
//        }
        return super.onOptionsItemSelected(item);
    }


}
