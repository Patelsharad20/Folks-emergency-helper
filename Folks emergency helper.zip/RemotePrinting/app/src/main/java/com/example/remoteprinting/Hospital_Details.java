package com.example.remoteprinting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.hbb20.CountryCodePicker;

public class Hospital_Details extends AppCompatActivity {


    EditText userName, userAddress, userPhone, userMessage;
    Button sub;
    TextView map;
    CountryCodePicker ccp;

    private int STORAGE_PERMISSION_CODE = 1;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital__details);


        getSupportActionBar().setTitle("HospitalDetails");
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        getIncomingIntent();

        setupUIViews();


        sub.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                String useremail = userAddress.getText().toString().trim();

                if (useremail.equals("")) {
                    Toast.makeText(Hospital_Details.this, "Please enter your Detail", Toast.LENGTH_SHORT).show();
                } else {


                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("message/plain");
                    i.putExtra(Intent.EXTRA_EMAIL, new String[]{"patelmeet3111999@gmail.com"});
                    i.putExtra(Intent.EXTRA_SUBJECT, "User Form");
                    i.putExtra(Intent.EXTRA_TEXT, "Name:" + userName.getText() + "\n Phone:" + userPhone.getText() + "\n Address:" + userAddress.getText()
                    + "\n Message:" + userMessage.getText());

                    try {
                        startActivity(Intent.createChooser(i, "Please select Email"));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(Hospital_Details.this, "there are no email client", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });

        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(Hospital_Details.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    startActivity(new Intent(Hospital_Details.this, Map.class));
                } else {
                    requestLocation();
                }
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void requestLocation() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {

            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed")
                    .setMessage("This Permission For Your Current Location ")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(Hospital_Details.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, STORAGE_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    }).create()
                    .show();

        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, STORAGE_PERMISSION_CODE);
        }


    }


    private void getIncomingIntent() {

        if (getIntent().hasExtra("image_url") && getIntent().hasExtra("image_name")) {

            String imageUrl = getIntent().getStringExtra("image_url");
            String imageName = getIntent().getStringExtra("image_name");
            String email_id = getIntent().getStringExtra("email_ids");
            String phone = getIntent().getStringExtra("phone_number");
            String add = getIntent().getStringExtra("address");

            setImage(imageUrl, imageName, email_id, phone, add);

        }
    }

    private void setImage(String imageUrl, String imageName, String email_id, String phone_number, String address) {

        TextView name = findViewById(R.id.image_description);
        name.setText(imageName);

        ImageView image = findViewById(R.id.hdImage);

        TextView email = findViewById(R.id.email_description);
        email.setText(email_id);

        TextView phone = findViewById(R.id.hospital_phone);
        phone.setText(phone_number);

        TextView add = findViewById(R.id.hospital_address);
        add.setText(address);

        Glide.with(this)
                .asBitmap()
                .load(imageUrl)
                .into(image);

    }

    private void setupUIViews() {
        userName = findViewById(R.id.hName);
        userAddress = findViewById(R.id.hAddress);
        sub = findViewById(R.id.hSubmit);
        userPhone = findViewById(R.id.hPhone);
        userMessage = findViewById(R.id.hMessage);

        map = findViewById(R.id.hdMap);


    }

}