package com.example.remoteprinting;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FeaturedAdpater  extends RecyclerView.Adapter<FeaturedAdpater.featuredViewHolder> {

    ArrayList<FeaturedHelperClass> featuredLocations;


    private ArrayList<String> mImageNames = new ArrayList<>();
    private ArrayList<String> mImage = new ArrayList<>();
    private Context mContext;

//    public FeaturedAdpater(ArrayList<String> mImageNames, ArrayList<String> mImage, Context mContext) {
//        this.mImageNames = mImageNames;
//        this.mImage = mImage;
//        this.mContext = mContext;
//    }

    public FeaturedAdpater(ArrayList<FeaturedHelperClass> featuredLocations) {
        this.featuredLocations = featuredLocations;
        this.mImageNames = mImageNames;
        this.mImage = mImage;
        this.mContext = mContext;
    }

//    public FeaturedAdpater(ArrayList<FeaturedHelperClass> featuredLocations) {
//        this.featuredLocations = featuredLocations;
//    }

    @NonNull
    @Override
    public featuredViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.featured_card_design,parent,false);
        featuredViewHolder featuredViewHolder = new featuredViewHolder(view);
        return featuredViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull featuredViewHolder holder, final int position) {

        FeaturedHelperClass featuredHelperClass = featuredLocations.get(position);
        holder.image.setImageResource(featuredHelperClass.getImage());
        holder.title.setText(featuredHelperClass.getTitle());
        holder.desc.setText(featuredHelperClass.getDescription());

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return featuredLocations.size();
    }

    public  static  class  featuredViewHolder extends RecyclerView.ViewHolder{


        ImageView image;
        TextView title,desc;


        public featuredViewHolder(@NonNull View itemView) {
            super(itemView);

            //Hooks
            image = itemView.findViewById(R.id.featured_image);
            title = itemView.findViewById(R.id.featured_title);
            desc = itemView.findViewById(R.id.featured_desc);


        }
    }

}
