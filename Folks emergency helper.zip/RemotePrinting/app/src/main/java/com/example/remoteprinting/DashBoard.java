package com.example.remoteprinting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class DashBoard extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);


        loadFragment(new HomFragment());
        bottomNavigationView = findViewById(R.id.bottom_d);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

//        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomFragment()).commit();
//        bottomMenu();


    }

    public boolean loadFragment(Fragment fragment) {


        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.parent_container, fragment)
                    .commit();
        }


        return true;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment fragment = null;
        switch (item.getItemId()) {
            case R.id.home:
                fragment = new HomFragment();
                break;

            case R.id.doctors:
                Intent intent = new Intent(DashBoard.this,DocFragment.class);
                startActivity(intent);
                break;

            case R.id.pf:
                fragment = new ProFragment();
                break;


        }


        return loadFragment(fragment);
    }


//    private void bottomMenu() {
//
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                Fragment fragment = null;
//                switch (item.getItemId()) {
//                    case R.id.home:
//                       fragment = new HomFragment();
//                       break;
//
//                    case R.id.doctors:
//                        fragment = new DocFragment();
//                        break;
//
//                    case R.id.pf:
//                        fragment = new ProFragment();
//                        break;
//
//
//                }
//
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,fragment).commit();
//
//                return true;
//            }
//        });
//
//    }


    @Override
    public void onBackPressed() {

        if (bottomNavigationView.getSelectedItemId() == R.id.home) {

            super.onBackPressed();
            finish();
        }
        else {
            bottomNavigationView.setSelectedItemId(R.id.home);
        }

    }
}