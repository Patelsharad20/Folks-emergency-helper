package com.example.remoteprinting;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

public class FeedBack extends AppCompatActivity {

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);


        getSupportActionBar().setTitle("FeedBack");
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        final EditText e1 = (EditText) findViewById(R.id.e1);
        final EditText e2 = (EditText) findViewById(R.id.e2);
        final RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/plain");
                i.putExtra(Intent.EXTRA_EMAIL, new String[]{"patelmeet3111999@gmail.com"});
                i.putExtra(Intent.EXTRA_SUBJECT, "Feedback From App");
                i.putExtra(Intent.EXTRA_TEXT, "Name:" + e1.getText() + "\n Message:" + e2.getText() + "\n Ratings:" + ratingBar.getRating());

                try {
                    startActivity(Intent.createChooser(i, "Please select Email"));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(FeedBack.this, "there are no email client", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}