package com.example.remoteprinting;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class RegistrationOption extends AppCompatActivity {


    Button HC_users, R_users;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_option);






        HC_users = findViewById(R.id.roButton1);
        R_users = findViewById(R.id.roButton2);



        HC_users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationOption.this,HC_Registration.class));
            }
        });


        R_users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegistrationOption.this,RegistrationActivity.class));
            }
        });

    }
}