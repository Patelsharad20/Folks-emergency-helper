package com.example.remoteprinting;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.net.CookieHandler;
import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{

    private ArrayList<String> mImageNames = new ArrayList<>();
    private ArrayList<String> mImages = new ArrayList<>();
    private ArrayList<String> mEmail = new ArrayList<>();
    private ArrayList<String> mPhone = new ArrayList<>();
    private ArrayList<String> mAddress = new ArrayList<>();
    private Context mContext;

    public RecyclerViewAdapter(Context context , ArrayList<String> imageNames, ArrayList<String> images ,ArrayList<String> emails, ArrayList<String> phones, ArrayList<String> add) {
        mImageNames = imageNames;
        mImages = images;
        mContext = context;
        mEmail = emails;
        mPhone = phones;
        mAddress = add;
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_listitems,parent,false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

        Glide.with(mContext)
                .asBitmap()
                .load(mImages.get(position))
                .into(holder.image);

        holder.imageName.setText(mImageNames.get(position));


        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(mContext, mImageNames.get(position),Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(mContext,Hospital_Details.class);
                intent.putExtra("image_url",mImages.get(position));
                intent.putExtra("image_name",mImageNames.get(position));
                intent.putExtra("email_ids",mEmail.get(position));
                intent.putExtra("phone_number",mPhone.get(position));
                intent.putExtra("address",mAddress.get(position));
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mImageNames.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        CircleImageView image;
        TextView imageName,mEmail,mPhone,mAddress;
        RelativeLayout parentLayout;

        public ViewHolder(View itemView){
            super(itemView);
            image = itemView.findViewById(R.id.rimage);
            imageName = itemView.findViewById(R.id.image_name);
            parentLayout = itemView.findViewById(R.id.parent_layout);
            mEmail = itemView.findViewById(R.id.email_description);
            mPhone = itemView.findViewById(R.id.hospital_phone);
            mAddress = itemView.findViewById(R.id.hospital_address);
        }

    }

}
