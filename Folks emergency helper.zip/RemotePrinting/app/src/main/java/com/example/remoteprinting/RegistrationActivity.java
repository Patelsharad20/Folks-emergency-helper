package com.example.remoteprinting;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hbb20.CountryCodePicker;

public class RegistrationActivity extends AppCompatActivity {

    EditText userName, userPassword, userEmail, userPhone;
    Button regButton;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    FirebaseAuth firebaseAuth;
    CountryCodePicker ccp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        setupUIViews();


        checkConnection();





        firebaseAuth = FirebaseAuth.getInstance();

        regButton.setOnClickListener(new View.OnClickListener() {



            @Override
            public void onClick(View view) {


                if (validate()){
                    String user_email = userEmail.getText().toString().trim();
                    String user_password = userPassword.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(user_email , user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                               sendEmailVerification();
                            }else {
                                Toast.makeText(RegistrationActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }

//    private void showCustomDialog() {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(RegistrationActivity.this);
//        builder.setMessage("Please Connect To The Internet to proceed further")
//                .setCancelable(false)
//                .setPositiveButton("Connect", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                      startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
//                    }
//                })
//                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//
//                        startActivity(new Intent(getApplicationContext(),StartUpScreen.class));
//                        finish();
//                    }
//                });
//
//    }


    public void checkConnection() {

        ConnectivityManager manager = (ConnectivityManager) getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = manager.getActiveNetworkInfo();

        if (null != activeNetwork) {

            if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {
                Toast.makeText(this, "Wifi Enabled", Toast.LENGTH_SHORT).show();
            } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                Toast.makeText(this, "Phone Data Enabled", Toast.LENGTH_SHORT).show();
            }


        }
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(RegistrationActivity.this);
            builder.setMessage("Please Connect To The Internet to proceed further")
                .setCancelable(false)
                .setPositiveButton("Connect", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                      startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        startActivity(new Intent(getApplicationContext(),StartUpScreen.class));
                        finish();
                    }
                });
            AlertDialog alert = builder.create();
            alert.show();


        }
    }


    private void setupUIViews() {
        userName = findViewById(R.id.etUserName);
        userPassword = findViewById(R.id.etUserPassword);
        userEmail = findViewById(R.id.etUserEmail);
        regButton = findViewById(R.id.etRegister);
        userPhone = findViewById(R.id.etPhone);
        ccp = findViewById(R.id.ccp);
//        ccp.registerCarrierNumberEditText(userPhone);
    }
    String name,password,email,phone;

//    private Boolean validateName() {
//        String val = userName.getEditText().getText().toString();
//        String noWhitespace = "\\A\\w{4,20}\\z";
//
//        if (val.isEmpty()) {
//            userName.setError("Field can't be empty");
//            return false;
//        }
////        else if (!val.matches(noWhitespace)){
////            userName.setError("White Spaces are not allowed");
////            return false;
////        }
//        else {
//            userName.setError(null);
//            userName.setErrorEnabled(false);
//            return true;
//        }
//    }
//    private Boolean validateEmail() {
//        String val = userEmail.getEditText().getText().toString();
//        String emailPattern = "[a-zA-Z0-9_.-]+@[a-zA-Z0-9.-].+[a-z]";
//
//        if (val.isEmpty()) {
//            userEmail.setError("Field can't be empty");
//            return false;
//        }else if (!val.matches(emailPattern)){
//            userEmail.setError("Invalid Email address");
//            return false;
//        }
//        else {
//            userEmail.setError(null);
//            return true;
//        }
//    }
//    private Boolean validatePassword() {
//        String val = userPassword.getEditText().getText().toString();
//        String password = "^" +
//                "(?=.*[0-9])"  +     //at least 1 digit
//                "(?=.*[a-zA-Z])" +    //any letter
//                "\\A\\w{4,20}\\z"     +     //no white space
////                ".{4,}"  +           //at least 4 characters
//                "$";
//
//        if (val.isEmpty()) {
//            userPassword.setError("Field can't be empty");
//            return false;
//        }else if (!val.matches(password)){
//            userPassword.setError("Password is too weak");
//            return false;
//        }
//
//        else {
//            userPassword.setError(null);
//            return true;
//        }
//    }
//    private Boolean validatePhone() {
//        String val = userPhone.getEditText().getText().toString();
//
//        if (val.isEmpty()) {
//            userPhone.setError("Field can't be empty");
//            return false;
//        } else {
//            userPhone.setError(null);
//            return true;
//        }
//    }

    private boolean validate(){
        Boolean result = false;
        name = userName.getText().toString();
         password = userPassword.getText().toString();
         email = userEmail.getText().toString();
         phone = ccp.getSelectedCountryCodeWithPlus() + userPhone.getText().toString();
        String emailPattern = "[a-zA-Z0-9_.-]+@[a-zA-Z0-9.-].+[a-z]";
        String num ="^\\+(?:[0-9] ?){6,14}[0-9]$";       //"(0/91)?[7-9][0-9]{9}"   //"^\\+(?:[0-9] ?){6,14}[0-9]$"  //"^\\+(?:[0-9] ?){6,14}[0-9]$"


        if (name.isEmpty() | password.isEmpty() | email.isEmpty() | phone.isEmpty()){
            userName.setError("Field cannot be empty");
            userEmail.setError("Field cannot be empty");
            userPassword.setError("Field cannot be empty");
            userPhone.setError("Field cannot be empty");
        }
        else if(!email.matches(emailPattern)){
            userEmail.setError("Invalid email address");
            return false;
        }
        else if (!phone.matches(num)){
            userPhone.setError("Enter Valid Number");
            return false;
        }
        else {
            userName.setError(null);
            result = true;
        }
        return result;
    }


    private void sendEmailVerification(){
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if (firebaseUser != null){
            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                  if (task.isSuccessful()){
                      sendUserData();
                      Toast.makeText(RegistrationActivity.this, "Successfully Registered,Verification mail send!", Toast.LENGTH_SHORT).show();
                      firebaseAuth.signOut();
                      finish();
                      startActivity(new Intent(RegistrationActivity.this,MainActivity.class));
                  }else {
                      Toast.makeText(RegistrationActivity.this,"Verification mail has not been send!",Toast.LENGTH_SHORT).show();
                  }
                }
            });
        }
    }

    private void sendUserData(){
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = firebaseDatabase.getReference(firebaseAuth.getUid());
        UserProfile userProfile = new UserProfile(name,email,phone);
        myRef.setValue(userProfile);
    }
}
