package com.example.remoteprinting;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.zip.Inflater;


public class DocFragment extends AppCompatActivity {


//    private static final String TAG = "DocFragment";
//    private ArrayList<String> mNames = new ArrayList<>();
//    private ArrayList<String> mImageUrls = new ArrayList<>();
//    private ArrayList<String> mMail = new ArrayList<>();
//
//
//
//
//
////    @Override
////    public View onCreateView(LayoutInflater inflater, ViewGroup container,
////                             Bundle savedInstanceState) {
////
////        initImageBitmaps();
////        recyclerView= container.findViewById(R.id.recycler_view);
////
////        // Inflate the layout for this fragment
////        return inflater.inflate(R.layout.fragment_doc, container, false);
////
////
////    }
//
//
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.fragment_doc);
//
//
//        initImageBitmaps();
//
//    }
//
//    private void initImageBitmaps(){
//
//        mImageUrls.add("https://www.bing.com/images/search?q=Apollo+Hospital+Logo&FORM=IRTRRL");
//        mNames.add("Apollo Hospital");
//        mMail.add("xyzemail@gmail.com");
//
//        mImageUrls.add("https://www.devasyahospital.com/wp-content/uploads/2018/12/logo.png");
//        mNames.add("Devasya kidney Hospitals");
//
//        mImageUrls.add("https://www.joonsquare.com/usermanage/image/business/sterling-hospital-rajkot-5773/sterling-hospital-rajkot-logo.jpg");
//        mNames.add("Sterling Hospital");
//
//        mImageUrls.add("https://bingo.icbse.com/business.jpg?action=logo&id=v30p5p");
//        mNames.add("Civil Hospital");
//
//        mImageUrls.add("https://www.joonsquare.com/usermanage/image/business/rajasthan-hospital-ahmedabad-5434/rajasthan-hospital-ahmedabad-logo.png");
//        mNames.add("Rajasthan Hospital");
//
//        mImageUrls.add("https://ehealth.eletsonline.com/wp-content/uploads/2016/05/Shalby-Hospitals-Ahmedabad-logo.jpg");
//        mNames.add("Shalby Hospital");
//
//        initRecyclerView();
//    }
//
//    private void initRecyclerView(){
//
//        Log.d(TAG, "initRecyclerView: init recyclerview.");
//
//
//
//
//        RecyclerView recyclerView = findViewById(R.id.recycler_view);
//
//        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, mNames , mImageUrls,mMail);
//        recyclerView.setAdapter(adapter);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//
//
//    }
}